const express = require('express');
const mongoose = require('mongoose');
const routes = require('./routes');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/nova pasta', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('Conectado na atividade'))
.catch((err) => console.error('Erro ao conectar na atividade:', err));

app.use(routes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
