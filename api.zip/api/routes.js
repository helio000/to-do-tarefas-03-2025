const Usuario = require('./controller/usuarios');
const Tarefa = require('./controller/tarefas');

// Rotas de usuários
routes.post('/usuarios', Usuario.create);
routes.get('/usuarios', Usuario.read);
routes.get('/usuarios/:id', Usuario.readOne);
routes.put('/usuarios/:id', Usuario.update);
routes.delete('/usuarios/:id', Usuario.remove);

// Rotas de tarefas
routes.post('/tarefas', Tarefa.create);
routes.get('/tarefas', Tarefa.read);
routes.get('/tarefas/:id', Tarefa.readOne);
routes.put('/tarefas/:id', Tarefa.update);
routes.delete('/tarefas/:id', Tarefa.remove);
