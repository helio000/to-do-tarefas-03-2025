
const Tarefa = require('./Tarefa.js');

const create = async (req, res) => {
    try {
        const tarefa = new Tarefa(req.body);
        await tarefa.save();
        res.status(201).json(tarefa);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const read = async (req, res) => {
    try {
        const tarefas = await Tarefa.find();
        res.status(200).json(tarefas);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const readOne = async (req, res) => {
    const { id } = req.params;
    try {
        const tarefa = await Tarefa.findById(id);
        if (!tarefa) return res.status(404).json({ error: 'Tarefa não encontrada' });
        res.status(200).json(tarefa);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const update = async (req, res) => {
    const { id } = req.params;
    try {
        const tarefa = await Tarefa.findByIdAndUpdate(id, req.body, { new: true });
        if (!tarefa) return res.status(404).json({ error: 'Tarefa não encontrada' });
        res.status(200).json(tarefa);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const remove = async (req, res) => {
    const { id } = req.params;
    try {
        const tarefa = await Tarefa.findByIdAndDelete(id);
        if (!tarefa) return res.status(404).json({ error: 'Tarefa não encontrada' });
        res.status(200).json({ message: 'Tarefa removida com sucesso' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

module.exports = { create, read, readOne, update, remove };
